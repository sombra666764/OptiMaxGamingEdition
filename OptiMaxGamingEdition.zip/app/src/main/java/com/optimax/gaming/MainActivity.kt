package com.optimax.gaming

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.optimax.gaming.ui.theme.OptiMaxGamingEditionTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            OptiMaxGamingEditionTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    OptiMaxApp()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OptiMaxApp() {
    val dnsManager = remember { DNSManager(LocalContext.current) }
    val storageCleaner = remember { StorageCleaner(LocalContext.current) }
    val processManager = remember { ProcessManager(LocalContext.current) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("OptiMax Gaming Edition") })
        }
    ) {\n        paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Módulo: "Ultra Clean" (Memoria)
            Card(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Ultra Clean (Memoria)", style = MaterialTheme.typography.headlineSmall)
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = { /* Lógica para limpiar caché */ }) {
                        Text("Limpiar Caché de Apps")
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Button(onClick = { processManager.redirectToBackgroundAppSettings() }) {
                        Text("Gestionar Apps en Segundo Plano")
                    }
                }
            }

            // Módulo: "Conexión Rayo" (DNS para Free Fire)
            Card(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Conexión Rayo (DNS)", style = MaterialTheme.typography.headlineSmall)
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = { dnsManager.activateCloudflareDNS() }) {
                        Text("Activar DNS Cloudflare (1.1.1.1)")
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Button(onClick = { dnsManager.activateGoogleDNS() }) {
                        Text("Activar DNS Google (8.8.8.8)")
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Button(onClick = { dnsManager.deactivatePrivateDNS() }) {
                        Text("Desactivar DNS Privado")
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Button(onClick = { dnsManager.clearArpCache() }) {
                        Text("Limpiar Tabla ARP (Requiere Root)")
                    }
                }
            }

            // Módulo: "Optimización Visual"
            Card(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Optimización Visual", style = MaterialTheme.typography.headlineSmall)
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = { processManager.redirectToDeveloperOptions() }) {
                        Text("Reducir Animaciones del Sistema")
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Button(onClick = { processManager.toggleLowPowerMode(true) }) {
                        Text("Activar Modo Bajo Consumo (Manual)")
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    OptiMaxGamingEditionTheme {
        OptiMaxApp()
    }
}

// Contexto local para Compose
import androidx.compose.ui.platform.LocalContext
