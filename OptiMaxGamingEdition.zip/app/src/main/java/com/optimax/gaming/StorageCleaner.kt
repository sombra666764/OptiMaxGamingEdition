package com.optimax.gaming

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.util.Log
import java.io.File

class StorageCleaner(private val context: Context) {

    private val TAG = "StorageCleaner"

    // Función para obtener el tamaño total de caché de una aplicación específica
    // Nota: En Android moderno (API 26+), las aplicaciones no pueden acceder directamente
    // a la caché de otras aplicaciones por motivos de seguridad y privacidad.
    // Esta función es más útil para la propia caché de la app o para informar al usuario.
    fun getAppCacheSize(packageName: String): Long {
        var cacheSize: Long = 0
        try {
            val packageManager = context.packageManager
            val method = packageManager.javaClass.getMethod(
                "getPackageSizeInfo",
                String::class.java, Int::class.java, Class.forName("android.content.pm.IPackageStatsObserver")
            )
            // Esto requiere un IPackageStatsObserver, que es una interfaz interna y no accesible directamente.
            // Para Android 8.0 (API 26) y superior, este método está obsoleto o restringido.
            // La forma recomendada es que el usuario limpie la caché manualmente desde la configuración de Android.
            Log.w(TAG, "getAppCacheSize: Acceso directo a la caché de otras apps está restringido en Android moderno.")
            Log.w(TAG, "Se recomienda guiar al usuario a la configuración del sistema para limpiar la caché.")

            // Para la propia caché de esta app:
            val cacheDir = context.cacheDir
            if (cacheDir.exists()) {
                cacheSize = getDirSize(cacheDir)
            }

        } catch (e: Exception) {
            Log.e(TAG, "Error al obtener tamaño de caché: ${e.message}")
        }
        return cacheSize
    }

    // Función para limpiar la caché de la propia aplicación
    fun clearOwnAppCache(): Boolean {
        try {
            val cacheDir = context.cacheDir
            deleteDir(cacheDir)
            Log.d(TAG, "Caché de la propia app limpiada.")
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Error al limpiar la caché de la propia app: ${e.message}")
            return false
        }
    }

    // Función para limpiar archivos temporales de descargas y otros directorios comunes
    // Nota: El acceso a estas rutas puede requerir permisos de almacenamiento (READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE)
    // y en Android 11+ (API 30+) se necesita el permiso MANAGE_EXTERNAL_STORAGE para acceso amplio.
    fun cleanCommonTempFiles(): Long {
        var cleanedSize: Long = 0
        val commonTempPaths = listOf(
            File(context.getExternalFilesDir(null), "Download"),
            File(Environment.getExternalStorageDirectory(), "Download"),
            File(Environment.getExternalStorageDirectory(), "WhatsApp/Media/.Statuses"), // Estados de WhatsApp
            File(Environment.getExternalStorageDirectory(), "Android/media/com.whatsapp/WhatsApp/Media/.Statuses") // Nueva ruta de WhatsApp
            // Agrega más rutas comunes de caché/temporales aquí
        )

        for (path in commonTempPaths) {
            if (path.exists() && path.isDirectory) {
                Log.d(TAG, "Limpiando directorio: ${path.absolutePath}")
                cleanedSize += deleteDir(path)
            }
        }
        return cleanedSize
    }

    // Función auxiliar para obtener el tamaño de un directorio
    private fun getDirSize(dir: File): Long {
        var size: Long = 0
        if (dir.exists() && dir.isDirectory) {
            for (file in dir.listFiles() ?: emptyArray()) {
                size += if (file.isFile) file.length() else getDirSize(file)
            }
        }
        return size
    }

    // Función auxiliar para eliminar un directorio y su contenido
    private fun deleteDir(dir: File): Long {
        var deletedSize: Long = 0
        if (dir.exists() && dir.isDirectory) {
            for (file in dir.listFiles() ?: emptyArray()) {
                deletedSize += if (file.isFile) {
                    val fileSize = file.length()
                    file.delete()
                    fileSize
                } else {
                    deleteDir(file)
                }
            }
        }
        return deletedSize
    }

    // Función para obtener el espacio de almacenamiento disponible
    fun getAvailableInternalStorage(): Long {
        val stat = StatFs(Environment.getDataDirectory().path)
        return stat.availableBlocksLong * stat.blockSizeLong
    }

    // Función para obtener el espacio total de almacenamiento interno
    fun getTotalInternalStorage(): Long {
        val stat = StatFs(Environment.getDataDirectory().path)
        return stat.blockCountLong * stat.blockSizeLong
    }
}
